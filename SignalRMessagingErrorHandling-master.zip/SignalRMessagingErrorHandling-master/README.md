SignalR Messaging with Error Handling
=============================
http://damienbod.wordpress.com/2013/11/13/signalr-messaging-a-complete-client-with-a-console-application/

http://damienbod.wordpress.com/2013/11/20/signalr-a-complete-wpf-client-using-mvvm/

http://damienbod.wordpress.com/2013/11/12/signalr-messaging-a-more-complete-console-server/
