﻿using Damienbod.Slab;

namespace Damienbod.SignalR.Host
{
    class Program
    {
        static void Main(string[] args)
        {
            Startup.Start();
        }
    }
}
