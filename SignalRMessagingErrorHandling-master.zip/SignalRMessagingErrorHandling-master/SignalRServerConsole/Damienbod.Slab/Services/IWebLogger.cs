﻿namespace Damienbod.Slab.Services
{
    public interface IWebLogger
    {
        void Log(int log, string message);
    }
}