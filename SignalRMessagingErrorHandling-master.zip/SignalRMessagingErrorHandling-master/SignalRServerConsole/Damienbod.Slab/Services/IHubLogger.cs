﻿namespace Damienbod.Slab.Services
{
    public interface IHubLogger
    {
        void Log(int log, string message);
    }
}