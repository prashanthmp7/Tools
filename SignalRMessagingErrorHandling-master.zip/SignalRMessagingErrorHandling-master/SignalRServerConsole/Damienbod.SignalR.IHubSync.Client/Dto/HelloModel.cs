﻿namespace Damienbod.SignalR.IHubSync.Client.Dto
{
    public class HelloModel
    {
        public string Molly { get; set; }

        public int Age { get; set; }
    }
}
